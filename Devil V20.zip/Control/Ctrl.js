// Module
const fs = require('fs')

//Bot Settings
global.connect = true 
global.publicX = true 
global.owner = ['6285727819741'] 
global.developer = "KaiziDsini" 
global.botname = "Athena" 
global.version = "1.0.0" 

//Setting Sticker
global.packname = "Sticker By" 
global.author = "Always Kaizi" 

//Setting Media
global.ytube = "https://youtube.com/@AlwaysKaizi"
global.ttok = "https://tiktok.com/@kyy_dsini"
global.igram = "https://instagram.com/@kyy_smk2"
global.chtele = "https://t.me/alwayskaizi"
global.tgram = "https://t.me/KaiziDsini"

//Bug Name Settings
global.bak = {
Ios: " ⿻ᬃ*ALWAYS*⿻ ",
Andro: "⩟⬦𪲁Pantek̸̷̷̷𝐗͜͢𝐒 -", 
Crash: " ̶C̶r̶a̶s̶h̶U̶l̶t̶i̶m̶a̶̶t̶e ̶",
Freeze: "𝐔𝐥𝐭𝐢𝐦𝐚𝐭𝐞",
Ui: "ℭ𝔯𝔴𝔰𝔥 𝔘𝔦 𝔖𝔶𝔰𝔱𝔢𝔪"
}

//System Bot Settings
global.prefa = ['','!','.',',','🐤','🗿'] // Prefix // Not Change

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})